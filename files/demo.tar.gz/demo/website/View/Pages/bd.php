<h1>Ejemplo: base de datos</h1>
<?php
$db = &\sowerphp\core\Model_Datasource_Database::get();
/*$db->query('
    INSERT INTO parametro VALUES
        (\'mod1\', \'par1\', \'val1\'),
        (\'mod1\', \'par2\', \'val2\'),
        (\'mod2\', \'par1\', \'val1\'),
        (\'mod2\', \'par2\', \'val2\'),
        (\'mod3\', \'par1\', \'val1\')
    ;
');*/
new \sowerphp\general\View_Helper_Table ($db->getTableWithColsNames('
    SELECT * FROM parametro ORDER BY modulo, parametro
'), 'parametros', true);

?>

<h2>Ejemplos de otros métodos</h2>
<h3>getRow()</h3>
<?php debug($db->getRow('SELECT * FROM parametro WHERE modulo = \'mod1\' AND parametro = \'par1\'')); ?>
<h3>getCol()</h3>
<?php debug($db->getCol('SELECT modulo FROM parametro GROUP BY modulo ORDER BY modulo')); ?>
<h3>getValue()</h3>
<?php debug($db->getValue('SELECT valor FROM parametro WHERE modulo = \'mod1\' AND parametro = \'par1\'')); ?>
