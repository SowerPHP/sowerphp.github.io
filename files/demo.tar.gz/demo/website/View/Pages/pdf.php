<?php
$pdf = new \sowerphp\general\View_Helper_PDF();
$pdf->setFont ('freemono', 'B', 32);
$pdf->AddPage();
$logo = DIR_WEBSITE.'/webroot/img/logo.png';
$pdf->Image($logo, 10, 10, 0, 0, 'PNG', 'http://example.com');
$pdf->SetTextColorArray(array(255, 0, 0));
$pdf->MultiTexto (10, 50, 'Texto de varias filas', 'L', 60);
$pdf->Output('archivo.pdf');
exit(0);
