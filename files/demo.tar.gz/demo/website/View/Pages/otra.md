Otra página de inicio
=====================

Está es una página de inicio diferente.

Ver [la página de inicio original para más información](inicio).

Para iniciar sesión utilizar usuario **admin** y contraseña **admin**.
