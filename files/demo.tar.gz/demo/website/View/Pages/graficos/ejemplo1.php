<?php
$chart = new \sowerphp\general\View_Helper_Chart ();
$chart->vertical_bar ('Gráfico X vs Y', array(
	'XA' => array('x1'=>1,'x2'=>2,'x3'=>3,'x4'=>4,'x5'=>5,'x6'=>6),
	'XB' => array('x1'=>5,'x2'=>4,'x3'=>7,'x4'=>3,'x5'=>4,'x6'=>1),
));
