<?php
$email = new \sowerphp\core\Network_Email();
$email->to(\sowerphp\core\Configure::read('email.default.to'));
$email->subject('Mensaje de prueba');
if ($email->send('Probando envio de correo')===true)
    \sowerphp\core\Model_Datasource_Session::message('Correo electrónico ha sido enviado');
else
    \sowerphp\core\Model_Datasource_Session::message('Problemas al enviar el correo electrónico');
