<h1>Ejemplo: formularios</h1>
<?php
$f = new \sowerphp\general\View_Helper_Form ();

// formulario login
echo $f->begin(array('focus'=>'email', 'onsubmit'=>'Form.check()'));
echo $f->input(array(
    'name'=>'email',
    'label'=>'Email',
    'check'=>'notempty email',
    'help'=>'Ingrese su email'
));
echo $f->input(array(
    'type'=>'password',
    'name'=>'contrasenia',
    'label'=>'Contraseña',
    'check'=>'notempty',
    'help'=>'Ingrese su contraseña',
));
echo $f->end('Ingresar');

// js
echo $f->begin();
echo $f->input(array(
    'type' => 'js',
    'id' => 'items',
    'label' => 'Items',
    'titles' => array ('ID', 'Descripción'),
    'inputs' => array (array('name'=>'id'), array('name'=>'descripcion'))
));
echo $f->end();

// tableselect
echo $f->begin();
echo $f->input (array(
    'type'=>'tablecheck',
    'name'=>'items',
    'label'=>'Items',
    'titles'=>array('ID', 'Descripción'),
    'table'=>array(
        array(1, 'D1'),
        array(2, 'D2'),
        array(3, 'D3'),
    ),
));
echo $f->end('Seleccionar');

// table radios
echo $f->begin();
echo $f->input (array(
    'type'=>'tableradios',
    'name'=>'items',
    'label'=>'Items',
    'titles'=>array('Pregunta'),
    'options'=>array(
        1=>'Nunca es cierto',
        2=>'Raras veces es cierto',
        3=>'Algunas veces es cierto',
        4=>'Usualmente es cierto',
        5=>'Siempre es cierto'
    ),
    'table'=>array(
        array(1, 'Busco cosas que necesitan hacerse.'),
        array(2, 'Cuando enfrento un problema difícil, invierto el tiempo que sea necesario en encontrar una solución.'),
        array(3, 'Trato de terminar mi trabajo a tiempo.'),
    ),
));
echo $f->end('Enviar respuestas');

if (isset($_POST['submit'])) {
    debug ($_POST, true);
}
