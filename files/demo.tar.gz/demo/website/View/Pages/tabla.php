<h1>Ejemplo: tablas</h1>
<?php
new \sowerphp\general\View_Helper_Table (array(
    array('f1c1', 'f1c2', 'f1c3'),
    array('f2c1', 'f2c2', 'f2c3'),
    array('f3c1', 'f3c2', 'f3c3'),
    array('f4c1', 'f4c2', 'f4c3'),
), 'tabla', true);
