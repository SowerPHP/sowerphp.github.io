Hola mundo!
===========

Este es un *demo* de las funcionalidades básicas provistas por SowerPHP y parte
de sus extensiones.

Este *demo* hace uso de las extensiones:

- [sowerphp/layouts](http://sowerphp.org/doc/extensiones/layouts)
- [sowerphp/app](http://sowerphp.org/doc/extensiones/app)
- [sowerphp/general](http://sowerphp.org/doc/extensiones/general)
- [sowerphp/dev](http://sowerphp.org/doc/extensiones/dev)

Para iniciar sesión utilizar usuario **admin** y contraseña **admin**.

**Importante**: la base de datos es reiniciada cada 5 minutos. Si no puede
ingresar o tiene algún problema esperar y volver a intentar.
