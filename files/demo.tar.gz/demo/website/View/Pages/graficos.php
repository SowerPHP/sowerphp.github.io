<h1>Gráficos</h1>
<?php
$f = new \sowerphp\general\View_Helper_Form();
echo $f->begin(['onsubmit'=>'Form.check()']);
echo $f->input([
    'type'=>'radios',
    'name'=>'tipo',
    'label'=>'Tipo',
    'options'=>['pie'=>'Torta', 'vertical_bar'=>'Barras verticales']
]);
echo $f->input([
    'name'=>'titulo',
    'label'=>'Título',
    'check'=>'notempty'
]);
echo $f->input([
    'name'=>'serie',
    'label'=>'Nombre de la serie',
    'help'=>'Aplica solo al gráfico de barras'
]);
echo $f->input([
    'type'=>'js',
    'id' => 'items',
    'label' => 'Items',
    'titles' => array ('Glosa', 'Valor'),
    'inputs' => array (array('name'=>'glosa'), array('name'=>'valor'))
]);
echo $f->end('Crear gráfico');

if (isset($_POST['submit'])) {
    $data = [];
    $n_glosas = count($_POST['glosa']);
    for ($i=0; $i<$n_glosas; $i++) {
        $data[$_POST['glosa'][$i]] = $_POST['valor'][$i];
    }
    ob_clean();
    $chart = new \sowerphp\general\View_Helper_Chart();
    $options = ['disposition'=>'attachement', 'filename'=>\sowerphp\core\Utility_String::normalize($_POST['titulo']).'.png'];
    if ($_POST['tipo']=='pie')
        $chart->pie ($_POST['titulo'], $data, $options);
    else if ($_POST['tipo']=='vertical_bar')
        $chart->vertical_bar ($_POST['titulo'], [$_POST['serie']=>$data], $options);
}
?>

<h2>Ejemplo de un gráfico que se puede generar</h2>
<div style="text-align:center">
    <img src="<?=$_base?>/graficos/ejemplo1" alt="" />
</div>
