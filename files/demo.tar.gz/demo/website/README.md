Ejemplo de funcionalidades de SowerPHP
======================================

Para que el ejemplo funcione correctamente se debe cargar el código SQL que
está en demo.sql utilizando el siguiente comando:

	$ psql demo < demo.sql

También se puede hacer a través de pgadmin3 o software similar que se conecte
a PostgreSQL.

Además se debe configurar de forma correcta la base de datos y el correo
electrónico en el archivo Config/core.php

Vía web, en example.com/doc/html, encontrará la documentación HTML de este
ejemplo.
