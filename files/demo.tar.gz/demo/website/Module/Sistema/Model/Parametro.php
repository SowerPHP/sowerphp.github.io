<?php

/**
 * SowerPHP: Minimalist Framework for PHP
 * Copyright (C) SowerPHP (http://sowerphp.org)
 *
 * Este programa es software libre: usted puede redistribuirlo y/o
 * modificarlo bajo los términos de la Licencia Pública General GNU
 * publicada por la Fundación para el Software Libre, ya sea la versión
 * 3 de la Licencia, o (a su elección) cualquier versión posterior de la
 * misma.
 *
 * Este programa se distribuye con la esperanza de que sea útil, pero
 * SIN GARANTÍA ALGUNA; ni siquiera la garantía implícita
 * MERCANTIL o de APTITUD PARA UN PROPÓSITO DETERMINADO.
 * Consulte los detalles de la Licencia Pública General GNU para obtener
 * una información más detallada.
 *
 * Debería haber recibido una copia de la Licencia Pública General GNU
 * junto a este programa.
 * En caso contrario, consulte <http://www.gnu.org/licenses/gpl.html>.
 */

// namespace del modelo
namespace website\Sistema;

/**
 * Clase para mapear la tabla parametro de la base de datos
 * Comentario de la tabla: 
 * Esta clase permite trabajar sobre un registro de la tabla parametro
 * @author SowerPHP Code Generator
 * @version 2014-04-26 16:54:27
 */
class Model_Parametro extends \Model_App
{

    // Datos para la conexión a la base de datos
    protected $_database = 'default'; ///< Base de datos del modelo
    protected $_table = 'parametro'; ///< Tabla del modelo

    // Atributos de la clase (columnas en la base de datos)
    public $modulo; ///< character varying(20) NOT NULL DEFAULT '' PK 
    public $parametro; ///< character varying(20) NOT NULL DEFAULT '' PK 
    public $valor; ///< character varying(20) NOT NULL DEFAULT '' 

    // Información de las columnas de la tabla en la base de datos
    public static $columnsInfo = array(
        'modulo' => array(
            'name'      => 'Modulo',
            'comment'   => '',
            'type'      => 'character varying',
            'length'    => 20,
            'null'      => false,
            'default'   => "",
            'auto'      => false,
            'pk'        => true,
            'fk'        => null
        ),
        'parametro' => array(
            'name'      => 'Parametro',
            'comment'   => '',
            'type'      => 'character varying',
            'length'    => 20,
            'null'      => false,
            'default'   => "",
            'auto'      => false,
            'pk'        => true,
            'fk'        => null
        ),
        'valor' => array(
            'name'      => 'Valor',
            'comment'   => '',
            'type'      => 'character varying',
            'length'    => 20,
            'null'      => false,
            'default'   => "",
            'auto'      => false,
            'pk'        => false,
            'fk'        => null
        ),

    );

    // Comentario de la tabla en la base de datos
    public static $tableComment = '';

    public static $fkNamespace = array(); ///< Namespaces que utiliza esta clase

}
