<?php

// Menú para el módulo
\sowerphp\core\Configure::write('nav.module', array(
    '/usuarios' => array(
        'name' => 'Usuarios',
        'desc' => 'Mantenedor de usuarios y grupos del sistema',
        'imag' => '/sistema/usuarios/img/icons/48x48/grupo.png',
    ),
    '/enlaces' => array(
        'name' => 'Enlaces',
        'desc' => 'Mantenedor de enlaces del sistema',
        'imag' => '/sistema/enlaces/img/icons/48x48/enlaces.png',
    ),
    '/parametros/listar' => array(
        'name' => 'Parámetros',
        'desc' => 'Mantenedor de parámetros',
        'imag' => '/img/icons/48x48/configuracion.png',
    ),
));
