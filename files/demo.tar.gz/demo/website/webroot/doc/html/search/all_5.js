var searchData=
[
  ['model_5fparametro',['Model_Parametro',['../classwebsite_1_1Sistema_1_1Model__Parametro.html',1,'website::Sistema']]],
  ['model_5fparametros',['Model_Parametros',['../classwebsite_1_1Sistema_1_1Model__Parametros.html',1,'website::Sistema']]]
];
