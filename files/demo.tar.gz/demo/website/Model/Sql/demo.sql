--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth; Type: TABLE; Schema: public; Owner: delaf; Tablespace: 
--

CREATE TABLE auth (
    id integer NOT NULL,
    grupo integer NOT NULL,
    recurso character varying(300) NOT NULL
);


ALTER TABLE public.auth OWNER TO delaf;

--
-- Name: TABLE auth; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON TABLE auth IS 'Permisos de grupos para acceder a recursos';


--
-- Name: COLUMN auth.id; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN auth.id IS 'Identificador (serial)';


--
-- Name: COLUMN auth.grupo; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN auth.grupo IS 'Grupo al que se le condede el permiso';


--
-- Name: COLUMN auth.recurso; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN auth.recurso IS 'Recurso al que el grupo tiene acceso';


--
-- Name: auth_id_seq; Type: SEQUENCE; Schema: public; Owner: delaf
--

CREATE SEQUENCE auth_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_id_seq OWNER TO delaf;

--
-- Name: auth_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: delaf
--

ALTER SEQUENCE auth_id_seq OWNED BY auth.id;


--
-- Name: enlace; Type: TABLE; Schema: public; Owner: delaf; Tablespace: 
--

CREATE TABLE enlace (
    id integer NOT NULL,
    enlace character varying(50) NOT NULL,
    url character varying(300) NOT NULL,
    categoria integer NOT NULL
);


ALTER TABLE public.enlace OWNER TO delaf;

--
-- Name: TABLE enlace; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON TABLE enlace IS 'Enlaces de la aplicación';


--
-- Name: COLUMN enlace.id; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN enlace.id IS 'Identificador (serial)';


--
-- Name: COLUMN enlace.enlace; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN enlace.enlace IS 'Nombre del enlace';


--
-- Name: COLUMN enlace.url; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN enlace.url IS 'URL (dirección web)';


--
-- Name: COLUMN enlace.categoria; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN enlace.categoria IS 'Categoría a la que pertenece el enlace';


--
-- Name: enlace_categoria; Type: TABLE; Schema: public; Owner: delaf; Tablespace: 
--

CREATE TABLE enlace_categoria (
    id integer NOT NULL,
    categoria character varying(30) NOT NULL,
    madre integer
);


ALTER TABLE public.enlace_categoria OWNER TO delaf;

--
-- Name: TABLE enlace_categoria; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON TABLE enlace_categoria IS 'Categorías de los enlaces de la aplicación';


--
-- Name: COLUMN enlace_categoria.id; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN enlace_categoria.id IS 'Identificador (serial)';


--
-- Name: COLUMN enlace_categoria.categoria; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN enlace_categoria.categoria IS 'Nombre de la categoría';


--
-- Name: COLUMN enlace_categoria.madre; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN enlace_categoria.madre IS 'Categoría madre de esta categoría (en caso que pertenezca a una)';


--
-- Name: enlace_categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: delaf
--

CREATE SEQUENCE enlace_categoria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.enlace_categoria_id_seq OWNER TO delaf;

--
-- Name: enlace_categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: delaf
--

ALTER SEQUENCE enlace_categoria_id_seq OWNED BY enlace_categoria.id;


--
-- Name: enlace_id_seq; Type: SEQUENCE; Schema: public; Owner: delaf
--

CREATE SEQUENCE enlace_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.enlace_id_seq OWNER TO delaf;

--
-- Name: enlace_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: delaf
--

ALTER SEQUENCE enlace_id_seq OWNED BY enlace.id;


--
-- Name: grupo_id_seq; Type: SEQUENCE; Schema: public; Owner: delaf
--

CREATE SEQUENCE grupo_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grupo_id_seq OWNER TO delaf;

--
-- Name: grupo; Type: TABLE; Schema: public; Owner: delaf; Tablespace: 
--

CREATE TABLE grupo (
    id integer DEFAULT nextval('grupo_id_seq'::regclass) NOT NULL,
    grupo character varying(30) NOT NULL,
    activo boolean DEFAULT true NOT NULL
);


ALTER TABLE public.grupo OWNER TO delaf;

--
-- Name: TABLE grupo; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON TABLE grupo IS 'Grupos de la aplicación';


--
-- Name: COLUMN grupo.id; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN grupo.id IS 'Identificador (serial)';


--
-- Name: COLUMN grupo.grupo; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN grupo.grupo IS 'Nombre del grupo';


--
-- Name: COLUMN grupo.activo; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN grupo.activo IS 'Indica si el grupo se encuentra activo';


--
-- Name: parametro; Type: TABLE; Schema: public; Owner: delaf; Tablespace: 
--

CREATE TABLE parametro (
    modulo character varying(20) NOT NULL,
    parametro character varying(20) NOT NULL,
    valor character varying(20) NOT NULL
);


ALTER TABLE public.parametro OWNER TO delaf;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: delaf
--

CREATE SEQUENCE usuario_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_id_seq OWNER TO delaf;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: delaf; Tablespace: 
--

CREATE TABLE usuario (
    id integer DEFAULT nextval('usuario_id_seq'::regclass) NOT NULL,
    nombre character varying(30) NOT NULL,
    usuario character varying(20) NOT NULL,
    email character varying(20) NOT NULL,
    contrasenia character(64) NOT NULL,
    hash character(32) NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    ultimo_ingreso_fecha_hora timestamp without time zone,
    ultimo_ingreso_desde character varying(45),
    ultimo_ingreso_hash character(32),
    contrasenia_intentos smallint DEFAULT 3 NOT NULL,
    token character(64),
    usuario_ldap character varying(30)
);


ALTER TABLE public.usuario OWNER TO delaf;

--
-- Name: TABLE usuario; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON TABLE usuario IS 'Usuarios de la aplicación';


--
-- Name: COLUMN usuario.id; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.id IS 'Identificador (serial)';


--
-- Name: COLUMN usuario.nombre; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.nombre IS 'Nombre real del usuario';


--
-- Name: COLUMN usuario.usuario; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.usuario IS 'Nombre de usuario';


--
-- Name: COLUMN usuario.email; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.email IS 'Correo electrónico del usuario';


--
-- Name: COLUMN usuario.contrasenia; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.contrasenia IS 'Contraseña del usuario';


--
-- Name: COLUMN usuario.hash; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.hash IS 'Hash único del usuario (32 caracteres)';


--
-- Name: COLUMN usuario.activo; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.activo IS 'Indica si el usuario está o no activo en la aplicación';


--
-- Name: COLUMN usuario.ultimo_ingreso_fecha_hora; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.ultimo_ingreso_fecha_hora IS 'Fecha y hora del último ingreso del usuario';


--
-- Name: COLUMN usuario.ultimo_ingreso_desde; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.ultimo_ingreso_desde IS 'Dirección IP del último ingreso del usuario';


--
-- Name: COLUMN usuario.ultimo_ingreso_hash; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario.ultimo_ingreso_hash IS 'Hash del último ingreso del usuario';


--
-- Name: usuario_grupo; Type: TABLE; Schema: public; Owner: delaf; Tablespace: 
--

CREATE TABLE usuario_grupo (
    usuario integer NOT NULL,
    grupo integer NOT NULL,
    primario boolean DEFAULT false NOT NULL
);


ALTER TABLE public.usuario_grupo OWNER TO delaf;

--
-- Name: TABLE usuario_grupo; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON TABLE usuario_grupo IS 'Relación entre usuarios y los grupos a los que pertenecen';


--
-- Name: COLUMN usuario_grupo.usuario; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario_grupo.usuario IS 'Usuario de la aplicación';


--
-- Name: COLUMN usuario_grupo.grupo; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario_grupo.grupo IS 'Grupo al que pertenece el usuario';


--
-- Name: COLUMN usuario_grupo.primario; Type: COMMENT; Schema: public; Owner: delaf
--

COMMENT ON COLUMN usuario_grupo.primario IS 'Indica si el grupo es el grupo primario del usuario';


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: delaf
--

ALTER TABLE ONLY auth ALTER COLUMN id SET DEFAULT nextval('auth_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: delaf
--

ALTER TABLE ONLY enlace ALTER COLUMN id SET DEFAULT nextval('enlace_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: delaf
--

ALTER TABLE ONLY enlace_categoria ALTER COLUMN id SET DEFAULT nextval('enlace_categoria_id_seq'::regclass);


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: delaf
--

COPY auth (id, grupo, recurso) FROM stdin;
2	1001	/dev/bd/tablas
1	1000	*
3	1001	/sistema/usuarios/usuarios/*
\.


--
-- Name: auth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: delaf
--

SELECT pg_catalog.setval('auth_id_seq', 3, true);


--
-- Data for Name: enlace; Type: TABLE DATA; Schema: public; Owner: delaf
--

COPY enlace (id, enlace, url, categoria) FROM stdin;
1	SowerPHP	http://sowerphp.org	2
2	CakePHP	http://cakephp.org	2
3	CodeIgniter	http://ellislab.com/codeigniter	2
4	Struts	http://struts.apache.org	3
5	Spring	http://spring.io	3
6	¿Qué es un framework?	http://es.wikipedia.org/wiki/Framework	1
7	PHP	http://php.net	4
8	Java	https://www.java.com	4
\.


--
-- Data for Name: enlace_categoria; Type: TABLE DATA; Schema: public; Owner: delaf
--

COPY enlace_categoria (id, categoria, madre) FROM stdin;
1	Frameworks	\N
2	PHP	1
3	Java	1
4	Lenguajes de programación	\N
\.


--
-- Name: enlace_categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: delaf
--

SELECT pg_catalog.setval('enlace_categoria_id_seq', 4, true);


--
-- Name: enlace_id_seq; Type: SEQUENCE SET; Schema: public; Owner: delaf
--

SELECT pg_catalog.setval('enlace_id_seq', 8, true);


--
-- Data for Name: grupo; Type: TABLE DATA; Schema: public; Owner: delaf
--

COPY grupo (id, grupo, activo) FROM stdin;
1000	sysadmin	t
1007	usuarios	t
1001	appadmin	t
\.


--
-- Name: grupo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: delaf
--

SELECT pg_catalog.setval('grupo_id_seq', 1008, true);


--
-- Data for Name: parametro; Type: TABLE DATA; Schema: public; Owner: delaf
--

COPY parametro (modulo, parametro, valor) FROM stdin;
mod1	par2	val2
mod2	par1	val1
mod2	par2	val2
mod3	par1	otro valor
mod5	par1	nuevo valor 2
mod5	par2	nuevo valor A
mod6	par6	valor seis
mod1	par1	val1
\.


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: delaf
--

COPY usuario (id, nombre, usuario, email, contrasenia, hash, activo, ultimo_ingreso_fecha_hora, ultimo_ingreso_desde, ultimo_ingreso_hash, contrasenia_intentos, token, usuario_ldap) FROM stdin;
1031	usuario6	usuario6	usuario6@example.com	dc521af988015c5c9357140b8b7767be90e99bdffc70a4d594a36fd7685a2d2e	N8cHKPr4CGczVotWK3MRkclq3UO8bgGH	f	\N	\N	\N	3	\N	\N
1004	usuario dos	usuario2	usuario2@example.com	df25018578299dc1a4a514ba06663692be433b5e7915c19580bede2e1fa74b8a	ebXgn81w4cERtXSRkRJpzNiSV9FBR3vf	t	\N	\N	\N	3	\N	\N
1045	usuario8	usuario8	usuario8@example.com	3ba4caa0ae009305226cae0dbc5462e6f13ea339761ee6f68f1cb78b28cb36a1	DHm87MryRJMPQkoyuWl1c72oSrvoyxbB	t	\N	\N	\N	3	\N	\N
1002	user	user	user@example.com	04f8996da763b7a969b1028ee3007569eaf3a635486ddab211d512c85b9df8fb	ojUwRsUiMIR0mkgfVJ2eKTqUh6rCZ3wv	t	2014-05-04 10:12:14	::1	4ff9e2634d221e7c9092df863261da6b	3	\N	\N
1006	usuario cuatro	usuario4	usuario4@example.com	bba424281ffd6b74399ccefab821c1b27d333de2729d5128be505e06706c9569	AwXuCi8zwNsbYgBtJAZCXKeAmgcuRNEh	t	\N	\N	\N	3	\N	\N
1000	Administrador	admin	admin@example.com	8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918	SNzaOXWTKNX70N178MaD7hLSn2hPU1Bx	t	2014-10-25 13:09:08	::1	a82556677b3caa3112beb07a07117b49	3	\N	\N
\.


--
-- Data for Name: usuario_grupo; Type: TABLE DATA; Schema: public; Owner: delaf
--

COPY usuario_grupo (usuario, grupo, primario) FROM stdin;
1002	1001	t
1045	1001	f
1045	1007	f
1006	1007	f
1000	1000	t
\.


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: delaf
--

SELECT pg_catalog.setval('usuario_id_seq', 1045, true);


--
-- Name: auth_pkey; Type: CONSTRAINT; Schema: public; Owner: delaf; Tablespace: 
--

ALTER TABLE ONLY auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: enlace_categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: delaf; Tablespace: 
--

ALTER TABLE ONLY enlace_categoria
    ADD CONSTRAINT enlace_categoria_pkey PRIMARY KEY (id);


--
-- Name: enlace_pkey; Type: CONSTRAINT; Schema: public; Owner: delaf; Tablespace: 
--

ALTER TABLE ONLY enlace
    ADD CONSTRAINT enlace_pkey PRIMARY KEY (id);


--
-- Name: grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: delaf; Tablespace: 
--

ALTER TABLE ONLY grupo
    ADD CONSTRAINT grupo_pkey PRIMARY KEY (id);


--
-- Name: parametro_pk; Type: CONSTRAINT; Schema: public; Owner: delaf; Tablespace: 
--

ALTER TABLE ONLY parametro
    ADD CONSTRAINT parametro_pk PRIMARY KEY (modulo, parametro);


--
-- Name: usuario_grupo_pk; Type: CONSTRAINT; Schema: public; Owner: delaf; Tablespace: 
--

ALTER TABLE ONLY usuario_grupo
    ADD CONSTRAINT usuario_grupo_pk PRIMARY KEY (usuario, grupo);


--
-- Name: usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: delaf; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: grupo_grupo_idx; Type: INDEX; Schema: public; Owner: delaf; Tablespace: 
--

CREATE UNIQUE INDEX grupo_grupo_idx ON grupo USING btree (grupo);


--
-- Name: usuario_email_idx; Type: INDEX; Schema: public; Owner: delaf; Tablespace: 
--

CREATE UNIQUE INDEX usuario_email_idx ON usuario USING btree (email);


--
-- Name: usuario_hash_idx; Type: INDEX; Schema: public; Owner: delaf; Tablespace: 
--

CREATE UNIQUE INDEX usuario_hash_idx ON usuario USING btree (hash);


--
-- Name: usuario_usuario_idx; Type: INDEX; Schema: public; Owner: delaf; Tablespace: 
--

CREATE UNIQUE INDEX usuario_usuario_idx ON usuario USING btree (usuario);


--
-- Name: auth_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: delaf
--

ALTER TABLE ONLY auth
    ADD CONSTRAINT auth_grupo_fkey FOREIGN KEY (grupo) REFERENCES grupo(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enlace_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: delaf
--

ALTER TABLE ONLY enlace
    ADD CONSTRAINT enlace_categoria_fkey FOREIGN KEY (categoria) REFERENCES enlace_categoria(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enlace_categoria_madre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: delaf
--

ALTER TABLE ONLY enlace_categoria
    ADD CONSTRAINT enlace_categoria_madre_fkey FOREIGN KEY (madre) REFERENCES enlace_categoria(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuario_grupo_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: delaf
--

ALTER TABLE ONLY usuario_grupo
    ADD CONSTRAINT usuario_grupo_grupo_fkey FOREIGN KEY (grupo) REFERENCES grupo(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuario_grupo_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: delaf
--

ALTER TABLE ONLY usuario_grupo
    ADD CONSTRAINT usuario_grupo_usuario_fkey FOREIGN KEY (usuario) REFERENCES usuario(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

